// import axios from "axios";

// axios.defaults.baseURL = "http://192.168.0.196:8000/";

// const UseAxios = () => {
//   return;
// };

// export default UseAxios;
